let a = document.body.style.backgroundColor;
const getColor = () => {
    const randomNumber = Math.floor(Math.random() * 16777215);
    const randomCode = "#"+randomNumber.toString(16);
    document.body.style.backgroundColor = randomCode;
    document.getElementById("color-code").innerText = randomCode;
    a = console.log(document.getElementById("color-code").innerText)
}
document.getElementById("btn").addEventListener(
    "click",
    getColor
)
const copyText = () => {
    navigator.clipboard.writeText(a)
}
document.getElementById("btn1").addEventListener(
    "click",
    copyText
)
getColor();