let now = new Date();
// console.log(now.getHours())

let isMorning = now.getHours() > 5 && now.getHours() <= 12;
let isAfternoon = now.getHours() > 12 && now.getHours() <= 18;
let isEvening = now.getHours() > 18 && now.getHours() <= 22;
let isNight = (now.getHours() >= 0 && now.getHours() <= 5) || (now.getHours() > 22 && now.getHours() <= 23);
// console.log(isNight);

let a = "";
if (isMorning) {
    a = "Morning";
} else if (isAfternoon) {
    a = "Afternoon";
}
else if (isEvening) {
    a = "Evening";
} else if (isNight) {
    a = "Night";
}

document.querySelector(".dayTime").innerText = a;





function getMonthName(index) {
    const months = [
        'January', 'February', 'March', 'April',
        'May', 'June', 'July', 'August',
        'September', 'October', 'November', 'December'
    ];
    return months[index];
}

function AMorPM(c, d) {
    let e = "";
    if (c >= 0 && (c <= 11 && d <= 59)) {
        e = "AM";
    }
    else {
        e = "PM";
    }
    return e;
}

var today = new Date();
let b = today.getMonth();
b = getMonthName(b)
// console.log(today.getMonth())
// console.log(b);
var date = (today.getDate()) + ' ' + b + ' ' + (today.getFullYear());

// var today = new Date();
let c = today.getHours();
let d = today.getMinutes();
// let e = AMorPM(c, d);
// console.log(today)

let xx = String(d)
if (xx.length == 1) {
    // console.log(xx.length);
    xx = "0" + xx;
}

var time = today.getHours() + " : " + xx;

document.querySelector("#current-date").innerHTML = date;
document.querySelector('#time').innerHTML = time;

document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("myButton").onclick = function () {
        let myCity = document.getElementById("mySearch").value.trim();
        if (myCity !== "") {
            checkWeather(myCity);
        }
    };

    checkWeather("Rawalpindi");
});


async function otherFunction() {
    const otherUrl = "https://api.openweathermap.org/data/2.5/forecast?q=rawalpindi&units=metric&appid=dd332f7756dffa8a4e7ffff6ce015615";
    const r = await fetch(otherUrl)
    var d = await r.json();

    let f = (d.list[1].dt_txt).slice(11, 16);
    let hours = f.slice(0, 2);
    let minu = f.slice(4);
    let timee = AMorPM(hours, minu);

    document.querySelector("#abc1").innerHTML = f + " " + timee;
    document.querySelector("#weather-content1").innerHTML = d.list[1].main.temp + "°C";
    document.querySelector("#ghi1").innerHTML = d.list[1].weather[0].main;

    f = (d.list[2].dt_txt).slice(11, 16);
    hours = f.slice(0, 2);
    minu = f.slice(4);
    timee = AMorPM(hours, minu);

    document.querySelector("#abc2").innerHTML = d.list[2].dt_txt.slice(11, 16) + " " + timee;
    document.querySelector("#weather-content2").innerHTML = d.list[3].main.temp + "°C";
    document.querySelector("#ghi2").innerHTML = d.list[2].weather[0].main;

    f = (d.list[3].dt_txt).slice(11, 16);
    hours = f.slice(0, 2);
    minu = f.slice(4);
    timee = AMorPM(hours, minu);

    document.querySelector("#abc3").innerHTML = d.list[3].dt_txt.slice(11, 16) + " " + timee;
    document.querySelector("#weather-content3").innerHTML = d.list[4].main.temp + "°C";
    document.querySelector("#ghi3").innerHTML = d.list[3].weather[0].main;

    f = (d.list[4].dt_txt).slice(11, 16);
    hours = f.slice(0, 2);
    minu = f.slice(4);
    timee = AMorPM(hours, minu);

    document.querySelector("#abc4").innerHTML = d.list[4].dt_txt.slice(11, 16) + " " + timee;
    document.querySelector("#weather-content4").innerHTML = d.list[4].main.temp + "°C";
    document.querySelector("#ghi4").innerHTML = d.list[4].weather[0].main;
}
otherFunction();




otherFunction();


function updateWeather(data) {
    document.querySelector('#city-name').textContent = data.name;
    document.querySelector("#temperature-reading").textContent = data.main.temp + "°C";
    document.querySelector('#description').textContent = data.weather[0].main;
    document.querySelector("#wind-speed").textContent = data.wind.speed + " m/s";
    document.querySelector("#humidity").textContent = data.main.humidity + "%";
    document.querySelector("#pressure").textContent = data.main.pressure + " hPa";
    let a = data.main.sea_level;
    if (a === undefined) {
        a = " - "
    }
    else {
        a = data.main.sea_level + " hPa"
    }
    document.querySelector("#sea-level").textContent = a;
}

async function checkWeather(city) {
    const apiKey = "dd332f7756dffa8a4e7ffff6ce015615";
    const apiURL = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`;

    try {
        const response = await fetch(apiURL);
        if (!response.ok) {
            throw new Error('Weather data not found');
        }
        const data = await response.json();
        console.log(data);
        updateWeather(data);
    }
    catch (error) {
        console.error('Error fetching weather:', error.message);
    }
}


