let array = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]
];
let turnX = true;
let boxes = document.querySelectorAll('.box');
let xscore = 0;
let yscore = 0;

const checkWin = () => {
    for (let index of array) {
        let a = boxes[index[0]].innerText;
        let b = boxes[index[1]].innerText; 
        let c = boxes[index[2]].innerText; 
        if (a!='' && b!="" && c!="") {
            if (a=== b && b === c) {
                console.log("we have a winner");   
                document.getElementsByClassName('info')[0].innerText = a + " Won"; 
                console.log(a);
                if (a==="X") {
                    xscore++;
                    document.querySelector('.x-score').innerText = xscore;
                }
                else {
                    yscore++;
                    document.querySelector('.o-score').innerText = yscore;
                }
        
                for (let a of index) {
                    // console.log(a) + " ";
                    boxes[a].style.backgroundColor = "#bfacaa";
                    boxes[a].style.color = "#02020a";
                }

                
            }
        }
    }
}

boxes.forEach((box) => {
    box.addEventListener('click', () => {
        if (turnX) {
        if (box.innerText==='') {
            box.innerText = "X"
            turnX=false;
        }
    }
    else{
        if (box.innerText==='') {
            box.innerText = "O"
            turnX=true;
        }
    }
    let t="";
    if (turnX) {
        t="X";
    }else{t="O"}
    document.getElementsByClassName('info')[0].innerText = "Turn for "+t; 
    checkWin();
    
    })
});

const reset = document.querySelector('#reset');
reset.addEventListener('click', ()=>{
    boxes.forEach((box)=>{
        box.innerText = "";
    })
    turnX = true;
    document.getElementsByClassName('info')[0].innerText = "Turn for X"; 
    xscore = 0;
    yscore = 0;
    document.querySelector('.x-score').innerText = xscore;
    document.querySelector('.o-score').innerText = yscore;
    boxes.forEach((box)=>{
        box.style.removeProperty("background-color");
    })
})

const play = document.querySelector('#play');
play.addEventListener('click', ()=>{
    boxes.forEach((box)=>{
        box.innerText = "";
    })
    turnX = true;
    document.getElementsByClassName('info')[0].innerText = "Turn for X"; 
    boxes.forEach((box)=>{
        box.style.removeProperty("background-color");
    })
})

const container = document.querySelector('.container');
const main = document.querySelector('.main');
const start = document.querySelector('#start');
start.addEventListener('click', ()=>{
    main.style.transition = "opacity 0.4s ease";
    main.style.opacity = "0";
    main.style.display = "none";
    main.classList.add('display');
    container.classList.remove('display');
})